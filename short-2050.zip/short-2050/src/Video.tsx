// РОЛИК: шоты по таймингам голоса + голос + музыка + субтитры. Всё время — в секундах ГОЛОСА.
// Для нового ролика меняется только массив SHOTS (и сами шоты ниже).
import React from "react";
import { AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { loadFont } from "@remotion/google-fonts/Montserrat";
import plan from "./plan.json";
import { FPS, Scene3D, Room, Box, Sign, Clock, Bench, Plant, Lamp, Desk, Chair, Monitor, Doodle, Actor, pointKeys, bonkAt, useSec, HIP } from "./kit";

const { fontFamily } = loadFont("normal", { weights: ["900"], subsets: ["latin", "cyrillic"] });

// ===================================================================== ШОТЫ: «Ты проснулся в 2050-м»
// Тайминги шотов ПРЕДВАРИТЕЛЬНЫЕ (по паузам в озвучке). После `node tools/whisper.mjs public/voice.mp3 ru` — поправь T.
const T = [0, 7.4, 18.08, 23.38, 31.89, 38.1, 48.72, 55.65, 60.9];

const Street: React.FC<{ shot: number }> = ({ shot }) => {
  const sec = useSec();
  const taxiX = -3.2 + Math.max(0, sec - T[1]) * 0.42;
  return (<>
    <Box p={[0, -0.05, 0]} s={[16, 0.1, 9]} c="#5a5f66" line={false} r={0.9} />
    <Box p={[0, 0.04, -1.55]} s={[16, 0.1, 1.2]} c="#cfc7b4" />
    <Box p={[-3.6, 2.2, -3.0]} s={[2.8, 4.4, 1.6]} c="#c9856a" /><Box p={[-0.6, 1.7, -3.0]} s={[3.0, 3.4, 1.6]} c="#8fb2c7" /><Box p={[2.6, 2.6, -3.0]} s={[3.2, 5.2, 1.6]} c="#d6b86a" />
    <Sign p={[-3.6, 1.1, -2.17]} w={1.4} h={0.4} text="АПТЕКА" bg="#2f9e6a" fg="#ffffff" />
    <Sign p={[-0.6, 1.0, -2.17]} w={1.2} h={0.4} text="КАФЕ" bg="#d65a3a" fg="#ffffff" />
    <Sign p={[2.6, 1.1, -2.17]} w={1.3} h={0.4} text="МАГАЗИН" bg="#3a5fa8" fg="#ffffff" />
    <Box p={[1.1, 1.3, -1.45]} s={[0.1, 2.6, 0.1]} c="#3b3f45" /><Box p={[1.1, 2.55, -1.45]} s={[0.3, 0.8, 0.25]} c="#222" />
    <Box p={[1.1, 2.8, -1.32]} s={[0.16, 0.16, 0.04]} c="#2fe05a" e="#2fe05a" ei={1.3} line={false} />
    <Bench p={[-1.9, 0.1, -1.3]} /><Plant p={[-2.9, 0.1, -1.35]} h={0.9} /><Plant p={[3.3, 0.1, -1.35]} h={0.7} />
    <Box p={[2.0, 0.35, -1.25]} s={[0.35, 0.7, 0.35]} c="#4a5a4a" />
    <group position={[taxiX, 0, -0.2]}>
      <Box p={[0, 0.45, 0]} s={[2.0, 0.6, 0.9]} c="#f2c230" /><Box p={[0.1, 0.95, 0]} s={[1.1, 0.5, 0.86]} c="#bfe0ff" r={0.2} />
      <Box p={[0.1, 0.8, 0]} s={[0.3, 0.3, 0.3]} c="#a53a3a" /><Sign p={[0.1, 1.28, 0]} w={0.5} h={0.18} text="ТАКСИ" bg="#15151a" fg="#f2c230" />
      <Box p={[-0.6, 0.15, 0.48]} s={[0.4, 0.3, 0.08]} c="#222" /><Box p={[0.6, 0.15, 0.48]} s={[0.4, 0.3, 0.08]} c="#222" />
    </group>
    {shot === 6 ? (<>
      <group position={[-1.9, 1.9, -0.5]} scale={bonkAt(sec, 39.4)}><Sign p={[0, 0, 0]} w={0.9} h={0.45} text="КОД" bg="#15151a" fg="#4ae0ff" glow={1.2} /></group>
      <group position={[1.9, 1.9, -0.5]} scale={bonkAt(sec, 42.9)}><Sign p={[0, 0, 0]} w={1.3} h={0.45} text="КИРПИЧ" bg="#a0482e" fg="#ffffff" /></group>
    </>) : null}
    {shot === 7 ? (<group position={[0, 2.2, -0.9]} scale={bonkAt(sec, 49.6)}><Sign p={[0, 0, 0]} w={1.7} h={0.5} text="9,7 МЛРД" bg="#2b5bd6" fg="#ffffff" glow={0.5} /></group>) : null}
    <Lamp p={[0.5, 3.4, 0.2]} />
  </>);
};

const Kitchen: React.FC<{ kettleBonk?: number }> = ({ kettleBonk = 0 }) => {
  const sec = useSec();
  return (<>
    <Room wall="#e8d9a8" wain="#b88a4a" floor="#7a8f9a" />
    <Box p={[-2.1, 0.95, -1.5]} s={[0.9, 1.9, 0.7]} c="#e9edf0" r={0.4} metal={0.2} />
    <Sign p={[-2.1, 1.5, -1.14]} w={0.6} h={0.3} text="МОЛОКО ЗАКАЗАНО" bg="#15151a" fg="#4ae0ff" glow={0.6} sz={50} />
    <Box p={[-0.5, 0.45, -1.6]} s={[1.6, 0.9, 0.7]} c="#6f4a32" /><Box p={[-0.5, 0.92, -1.6]} s={[1.7, 0.05, 0.75]} c="#d9d4c8" />
    <group position={[-0.8, 1.1, -1.55]} scale={bonkAt(sec, kettleBonk)}>
      <Box p={[0, 0, 0]} s={[0.3, 0.3, 0.3]} c="#d8dde3" metal={0.5} r={0.3} /><Box p={[0.2, 0.05, 0]} s={[0.16, 0.06, 0.06]} c="#d8dde3" /><Box p={[0, 0.2, 0]} s={[0.12, 0.08, 0.12]} c="#222" />
    </group>
    <Sign p={[-0.5, 1.9, -1.97]} w={0.6} h={0.3} text="3:00" bg="#15151a" fg="#ff3b2f" glow={1.0} />
    <Clock p={[0.9, 2.3, -1.99]} hh={7} mm={30} /><Box p={[1.5, 0.4, -1.5]} s={[0.8, 0.8, 0.6]} c="#c9a24a" />
    <Desk p={[1.4, 0, -0.2]} w={1.2} /><Chair p={[0.5, 0, -0.1]} rotY={Math.PI / 2} /><Plant p={[2.5, 0, -1.4]} h={0.8} />
    <Sign p={[2.0, 1.7, -1.99]} w={0.5} h={0.7} text="РЕЦЕПТ" bg="#d65a7a" fg="#ffffff" sz={60} />
    <Lamp p={[0.2, 2.97, -0.2]} />
  </>);
};

const Retro: React.FC = () => {
  const sec = useSec();
  return (<>
    <Room wall="#8a8a5a" wain="#5c5c3a" floor="#6a4a32" />
    <Desk p={[-0.8, 0, -1.3]} w={1.5} /><Monitor p={[-0.8, 0.8, -1.5]} screen="#8fe0a0" />
    <Box p={[-0.15, 0.98, -1.2]} s={[0.14, 0.2, 0.05]} c="#2a3a6a" />
    <Sign p={[-0.15, 1.18, -1.15]} w={0.3} h={0.1} text="NOKIA" bg="#2a3a6a" fg="#ffffff" sz={60} />
    <Sign p={[1.3, 2.0, -1.99]} w={1.1} h={0.6} text={sec < 35.9 ? "2002" : "2007"} bg="#15151a" fg="#ffd24a" glow={0.8} />
    <Box p={[1.8, 0.5, -1.3]} s={[0.6, 1.0, 0.5]} c="#4a4a52" /><Box p={[2.5, 0.35, -1.5]} s={[0.5, 0.7, 0.5]} c="#b5703a" />
    <Clock p={[-2.2, 2.3, -1.99]} hh={3} mm={15} /><Plant p={[2.7, 0, -1.2]} h={0.7} /><Bench p={[0.3, 0, -1.5]} w={0.9} />
    <Lamp p={[0.4, 2.97, -0.2]} />
  </>);
};

const HERO = { body: "#4a90d9", hair: "bowl" as const };
const mk = (over: Partial<Actor>): Actor => ({ pos: [0, 0, -0.2], seed: 1, look: HERO, expr: [[0, "neutral"]], ...over });

const G = { body: "#9b6bb5", hair: "long" as const };
const SH = (t0: number, t1: number, cam: any, focus: [number, number, number], light: "day" | "night" | "studio", el: React.ReactNode) =>
  ({ t0, t1, el: <Scene3D t0={t0} cam={cam} focus={focus} light={light}>{el}</Scene3D> });

const SHOTS: { t0: number; t1: number; el: React.ReactNode }[] = [
  SH(T[0], T[1], [[T[0], [0.5, 1.3, 1.9], [0, 1.1, -0.5], 76], [T[1], [0.2, 1.3, 1.6], [0, 1.1, -0.5], 76]], [0, 1.2, -0.2], "day",
    <><Street shot={1} /><Doodle a={mk({ pos: [0, 0, -0.1], expr: [[0, "blank"], [1.6, "realize"], [3.0, "nervous"], [4.6, "shock"], [6.0, "blank"]], lean: [[0, 0, 0], [4.6, 0.1, 0]] })} /></>),
  SH(T[1], T[2], [[T[1], [-1.3, 1.3, 1.9], [0.4, 1.1, -0.8], 74], [T[2], [-0.9, 1.3, 1.6], [0.5, 1.1, -0.8], 74]], [0.1, 1.2, -0.4], "day",
    <><Street shot={2} />
      <Doodle a={mk({ pos: [-0.4, 0, -0.3], seed: 1, expr: [[T[1], "grin"], [T[1] + 1.5, "nervous"], [T[1] + 3.2, "blank"], [T[1] + 5.0, "realize"], [T[1] + 6.5, "stern"], [T[1] + 8.3, "shock"]],
        handB: pointKeys(T[1] + 8.4, 1.0, 0.1, 1.2, "b") })} />
      <Doodle a={mk({ pos: [1.4, 0, -0.7], seed: 2, look: G, expr: [[T[1], "neutral"], [T[1] + 3, "smug"], [T[1] + 6, "neutral"]], walk: [[T[1], 1.4, -0.7], [T[2], 0.9, -0.7]] })} /></>),
  SH(T[2], T[3], [[T[2], [0.4, 1.3, 1.6], [-0.5, 1.1, -1.3], 76], [T[3], [0.1, 1.3, 1.4], [-0.6, 1.2, -1.3], 76]], [-0.6, 1.2, -0.8], "day",
    <><Kitchen kettleBonk={T[2] + 2.2} />
      <Doodle a={mk({ pos: [-0.2, 0, -0.6], expr: [[T[2], "neutral"], [T[2] + 1.4, "blank"], [T[2] + 2.4, "smug"], [T[2] + 4.0, "holdlaugh"]], handB: pointKeys(T[2] + 4.4, -1.0, 0.7, 0.6, "f") })} /></>),
  SH(T[3], T[4], [[T[3], [0.8, 1.3, 1.7], [-0.4, 1.1, -0.9], 76], [T[4], [0.3, 1.3, 1.4], [-0.4, 1.1, -0.9], 76]], [-0.1, 1.2, -0.5], "day",
    <><Kitchen /><Doodle a={mk({ pos: [-0.1, 0, -0.5], expr: [[T[3], "shock"], [T[3] + 1.6, "nervous"], [T[3] + 3.4, "blank"], [T[3] + 5.2, "stern"], [T[3] + 7.0, "shock"]] })} /></>),
  SH(T[4], T[5], [[T[4], [0.9, 1.3, 1.9], [-0.2, 1.1, -1.0], 76], [T[5], [0.5, 1.3, 1.6], [-0.2, 1.1, -1.0], 76]], [-0.2, 1.2, -0.5], "day",
    <><Retro />
      <Doodle a={mk({ pos: [-0.5, 0, -0.5], expr: [[T[4], "grin"], [T[4] + 1.8, "proud"], [T[4] + 3.4, "realize"], [T[4] + 5.2, "laugh"]] })} />
      <Doodle a={mk({ pos: [0.9, 0, -0.5], seed: 3, look: { body: "#d65a7a", hair: "spiky" }, expr: [[T[4], "smug"], [T[4] + 3.4, "proud"], [T[4] + 5.0, "grin"]] })} /></>),
  SH(T[5], T[6], [[T[5], [-0.4, 1.3, 2.0], [0, 1.4, -1.0], 78], [T[6], [0.2, 1.3, 1.8], [0, 1.4, -1.0], 78]], [0, 1.2, -0.4], "day",
    <><Street shot={6} /><Doodle a={mk({ pos: [0, 0, -0.3], expr: [[T[5], "smug"], [T[5] + 2.0, "proud"], [T[5] + 4.2, "grin"], [T[5] + 6.0, "realize"], [T[5] + 8.2, "smug"]] })} /></>),
  SH(T[6], T[7], [[T[6], [0.6, 1.3, 2.0], [0, 1.5, -1.0], 78], [T[7], [0.1, 1.3, 1.7], [0, 1.5, -1.0], 78]], [0, 1.2, -0.4], "day",
    <><Street shot={7} />
      <Doodle a={mk({ pos: [-0.5, 0, -0.3], expr: [[T[6], "proud"], [T[6] + 1.8, "realize"], [T[6] + 3.6, "grin"], [T[6] + 5.2, "smug"]] })} />
      <Doodle a={mk({ pos: [0.9, 0, -0.7], seed: 2, look: G, expr: [[T[6], "neutral"], [T[6] + 3.6, "smug"]] })} /></>),
  SH(T[7], T[8], [[T[7], [0.7, 1.3, 1.5], [-0.6, 1.1, -1.4], 76], [T[8], [0.3, 1.25, 1.3], [-0.6, 1.1, -1.4], 76]], [-0.5, 1.2, -0.8], "day",
    <><Kitchen kettleBonk={T[7] + 2.3} />
      <Doodle a={mk({ pos: [-0.3, 0, -0.7], expr: [[T[7], "stern"], [T[7] + 1.7, "smug"], [T[7] + 3.4, "grin"]], handB: pointKeys(T[7] + 2.6, -1.0, 0.5, 1.5, "f") })} /></>),
];

// ===================================================================== субтитры (как в эталоне)
const Caption: React.FC = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const g = plan.groups.find((x) => f >= x.start && f < Math.max(x.end, x.start + 6));
  if (!g) return null;
  const s = spring({ frame: f - g.start, fps, config: { damping: 11, stiffness: 240, mass: 0.55 } });
  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 600 }}>
      <div style={{ fontFamily, fontWeight: 900, fontSize: 92, lineHeight: 1.05, color: "white", textAlign: "center", maxWidth: 920,
        transform: `scale(${interpolate(s, [0, 1], [0.72, 1])})`, WebkitTextStroke: "16px black", paintOrder: "stroke fill",
        textShadow: "0 6px 0 rgba(0,0,0,0.55)" }}>{g.text}</div>
    </AbsoluteFill>
  );
};

export const TOTAL = Math.round(SHOTS[SHOTS.length - 1].t1 * FPS);
export const Video: React.FC = () => {
  const { durationInFrames } = useVideoConfig();
  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      {SHOTS.map((s, i) => (
        <Sequence key={i} from={Math.round(s.t0 * FPS)} durationInFrames={Math.round((s.t1 - s.t0) * FPS)}>{s.el}</Sequence>
      ))}
      <Audio src={staticFile(plan.voice)} />
      <Audio src={staticFile("music.wav")} loop
        volume={(f) => interpolate(f, [0, 20, durationInFrames - 45, durationInFrames], [0, 0.11, 0.11, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Caption />
    </AbsoluteFill>
  );
};
